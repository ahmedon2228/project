using UnityEngine;

public class BackgroundSetter : MonoBehaviour
{
    [SerializeField] private Camera mainCamera;
    [SerializeField] private Color[] backgroundColors;

    private void Start()
    {
        int randomIndex = Random.Range(0, backgroundColors.Length);
        mainCamera.backgroundColor = backgroundColors[randomIndex];
    }
}
