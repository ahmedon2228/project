using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class Menu : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI recordText;

    private void Start()
    {
        int currentRecord = PlayerPrefs.GetInt("Record", 0);
        recordText.text = "best: " + currentRecord.ToString();
    }

    public void Play()
    {
        SceneManager.LoadScene("Game");
    }
}
