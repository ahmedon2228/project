using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class GameAnimator : MonoBehaviour
{
    [SerializeField] private Transform cameraTransform;
    [SerializeField] private Image screenFader;

    public void ShakeCamera()
    {
        cameraTransform.DOShakePosition(0.3f, 0.5f);
    }

    public void FadeScreenIn()
    {
        FadeScreen(0.4f, 0.2f);
    }

    public void FadeScreenOut()
    {
        FadeScreen(0f, 0.35f);
    }

    private void FadeScreen(float alphaValue, float duration)
    {
        screenFader.DOKill();
        screenFader.DOFade(alphaValue, duration);
    }
}
