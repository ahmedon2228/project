using UnityEngine;
using DG.Tweening;

public class CameraFollow : MonoBehaviour
{
    [SerializeField] private Camera mainCamera;
    [SerializeField] private Transform ballTransform;

    [SerializeField] private float zoomValue;
    [SerializeField] private float zoomDuration;
    [SerializeField] private float slerpDuration;

    [SerializeField] private Transform cameraMainPosition;
    [SerializeField] private Transform cameraTransform;

    private void OnEnable()
    {
        mainCamera.DOOrthoSize(zoomValue, zoomDuration);
    }

    private void FixedUpdate()
    {
        Vector3 direction = (Vector2)ballTransform.position - (Vector2)cameraMainPosition.position;
        Vector3 newPosition = cameraMainPosition.position + (direction * 0.1f);
        cameraTransform.position = Vector3.Slerp(cameraTransform.position, newPosition, slerpDuration);
    }
}
