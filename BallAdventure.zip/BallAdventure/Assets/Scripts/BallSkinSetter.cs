using UnityEngine;

public class BallSkinSetter : MonoBehaviour
{
    [SerializeField] private GameObject[] ballSkins;

    private void Start()
    {
        int randomIndex = Random.Range(0, ballSkins.Length);
        ballSkins[randomIndex].SetActive(true);
    }
}
