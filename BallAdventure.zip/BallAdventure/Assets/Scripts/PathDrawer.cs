using System.Linq;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class PathDrawer : MonoBehaviour
{
    [SerializeField] private GameObject ballGameObject;
    [SerializeField] private GameObject pauseButton;
    [SerializeField] private Transform ballTransform;
    [SerializeField] private BallMovement ballMovement;
    [SerializeField] private CameraFollow cameraFollow;

    [SerializeField] private Camera mainCamera;
    [SerializeField] private LineRenderer lineRenderer;
    [SerializeField] private float pathGenerationDelay;

    private float _pathLength;
    private List<Vector3> _path = new List<Vector3>();

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            if (EventSystem.current.IsPointerOverGameObject()) return;
            StartCoroutine(GeneratePath());
        }

        if (Input.GetMouseButtonUp(0))
        {
            if (EventSystem.current.IsPointerOverGameObject()) return;

            StopAllCoroutines();

            ballGameObject.SetActive(true);
            pauseButton.SetActive(false);
            ballTransform.position = _path[0];

            ballMovement.Move(_path.ToArray(), _pathLength);
            _path = new List<Vector3>();

            cameraFollow.enabled = true;
            enabled = false;
        }
    }

    private IEnumerator GeneratePath()
    {
        while (true)
        {
            Vector3 mousePosition = Input.mousePosition;
            Vector2 worldPosition = mainCamera.ScreenToWorldPoint(mousePosition);

            _path.Add(worldPosition);
            lineRenderer.positionCount = _path.Count;
            lineRenderer.SetPositions(_path.ToArray());

            if (_path.Count > 1)
            {
                _pathLength += Vector2.Distance(worldPosition, _path[_path.Count - 2]);
            }

            yield return new WaitForSeconds(pathGenerationDelay);
        }
    }
}
