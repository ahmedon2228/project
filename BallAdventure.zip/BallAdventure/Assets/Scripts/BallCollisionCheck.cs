using UnityEngine;
using DG.Tweening;

public class BallCollisionCheck : MonoBehaviour
{
    [SerializeField] private GameState gameState;
    [SerializeField] private StarCounter starCounter;
    [SerializeField] private GameObject starCollectParticle;
    [SerializeField] private GameObject failParticlePrefab;

    private Transform _thisObjectTransform;

    private void Awake()
    {
        _thisObjectTransform = transform;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Star"))
        {
            starCounter.StarsCount -= 1;

            Instantiate(starCollectParticle, collision.transform.position, Quaternion.identity);

            Destroy(collision.gameObject);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Wall"))
        {
            _thisObjectTransform.DOKill();

            Instantiate(failParticlePrefab, _thisObjectTransform.position, Quaternion.identity);

            gameState.Fail();

            gameObject.SetActive(false);
        }
    }
}
