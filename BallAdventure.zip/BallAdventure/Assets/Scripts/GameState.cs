using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class GameState : MonoBehaviour
{
    [SerializeField] private GameAnimator gameAnimator;
    [SerializeField] private PathDrawer pathDrawer;

    [SerializeField] private TextMeshPro levelIndexText;

    [SerializeField] private GameObject gamePanel;
    [SerializeField] private GameObject pausePanel;
    [SerializeField] private GameObject failPanel;
    [SerializeField] private GameObject winPanel;

    [SerializeField] private int levelIndex;

    private void Start()
    {
        levelIndexText.text = "level " + (levelIndex + 1).ToString();
    }

    public void Pause()
    {
        pathDrawer.enabled = false;

        gameAnimator.FadeScreenIn();

        gamePanel.SetActive(false);
        pausePanel.SetActive(true);
    }

    public void Unpause()
    {
        pathDrawer.enabled = true;

        gameAnimator.FadeScreenOut();

        gamePanel.SetActive(true);
        pausePanel.SetActive(false);
    }

    public void Fail()
    {
        Pause();
        gameAnimator.ShakeCamera();
        pausePanel.SetActive(false);
        failPanel.SetActive(true);
    }

    public void Win()
    {
        Pause();

        pausePanel.SetActive(false);
        winPanel.SetActive(true);

        PlayerPrefs.SetInt("Level" + (levelIndex + 1).ToString(), 1);
    }

    public void Retry()
    {
        SceneManager.LoadScene("Level" + levelIndex.ToString());
    }

    public void Menu()
    {
        SceneManager.LoadScene("Menu");
    }

    public void NextLevel()
    {
        SceneManager.LoadScene("Level" + (levelIndex + 1).ToString());
    }
}
