using UnityEngine;
using DG.Tweening;

public class BallMovement : MonoBehaviour
{
    [SerializeField] private GameState gameState;

    [SerializeField] private StarCounter starCounter;
    [SerializeField] private Transform ballTransform;
    [SerializeField] private float speed;

    public void Move(Vector3[] path, float pathLength)
    {
        Debug.Log(pathLength);

        float duration = Mathf.Pow(speed, -1) * pathLength;

        ballTransform.DOPath(path, duration).SetEase(Ease.Linear).OnComplete(() =>
        {
            if (starCounter.StarsCount == 0)
            {
                gameState.Win();
            }
            else
            {
                gameState.Fail();
            }
        });
    }
}
