using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class LevelButton : MonoBehaviour
{
    [SerializeField] private GameObject lockImage;
    [SerializeField] private GameObject levelIndexTextObject;

    [SerializeField] private TextMeshProUGUI levelIndexText;
    [SerializeField] private int levelIndex;

    private bool _isUnlocked;

    private void Start()
    {
        if (PlayerPrefs.GetInt("Level" + levelIndex.ToString(), 0) == 1 || levelIndex == 0)
        {
            lockImage.SetActive(false);
            levelIndexTextObject.SetActive(true);

            levelIndexText.text = (levelIndex + 1).ToString();

            _isUnlocked = true;
        }
    }

    public void Play()
    {
        if (!_isUnlocked) return;

        SceneManager.LoadScene("Level" + levelIndex.ToString());
    }
}
