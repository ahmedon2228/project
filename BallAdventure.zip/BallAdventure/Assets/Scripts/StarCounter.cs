using UnityEngine;

public class StarCounter : MonoBehaviour
{
    public int StarsCount;

    private void Start()
    {
        StarsCount = GameObject.FindGameObjectsWithTag("Star").Length;
    }
}
