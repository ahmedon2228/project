using UnityEngine;
using UnityEngine.SceneManagement;
using DG.Tweening;

public class GameLoader : MonoBehaviour
{
    [SerializeField] private RectTransform loadingBar;

    private void Start()
    {
        loadingBar.DOScaleX(1f, 5f).SetEase(Ease.Linear).OnComplete(() => SceneManager.LoadScene("Menu"));
    }
}
